<?php

/**
 * Form - Français
 */

return [

    'button' => 'Envoyer',
    'submit' => 'Envoyer',

];
