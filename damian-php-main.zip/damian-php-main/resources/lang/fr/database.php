<?php

/**
 * Database - Français
 */

return [

    'connection_error' => 'Le site web est actuellement en maintenance. Il sera de nouveau disponible très bientôt. Merci de revenir plus tard.',

];
