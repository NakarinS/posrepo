<?php

/**
 * Security - Français
 */

return [

    'csrf_token_post' => 'Pour des raisons de sécurité, la page a expirée. Merci de remplir à nouveau le formulaire.',

    'csrf_token_get' => 'Pour des raisons de sécurité, la page a expirée.',

];
