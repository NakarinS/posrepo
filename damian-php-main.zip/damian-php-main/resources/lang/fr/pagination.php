<?php

/**
 * Pagination - Français
 */

return [

    'all' => 'Tous',
    'first' => 'Début',
    'last' => 'Fin',
    'next'     => 'Suivant',
    'per_page' => 'Par page',
    'previous' => 'Précédent',

];
