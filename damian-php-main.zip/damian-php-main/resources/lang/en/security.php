<?php

/**
 * Security - English
 */

return [

    'csrf_token_post' => 'For security reasons, the page has expired. Please fill out the form again.',

    'csrf_token_get' => 'For security reasons, the page has expired.',

];
