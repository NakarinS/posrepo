<?php

/**
 * Pagination - English
 */

return [

    'all' => 'All',
    'first' => 'Beginning',
    'last' => 'End',
    'next'     => 'Next',
    'per_page' => 'Per page',
    'previous' => 'Previous',

];
