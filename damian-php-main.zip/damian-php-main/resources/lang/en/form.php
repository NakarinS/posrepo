<?php

/**
 * Form - English
 */

return [

    'button' => 'Send',
    'submit' => 'Send',

];
