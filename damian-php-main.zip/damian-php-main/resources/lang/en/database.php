<?php

/**
 * Database - Français
 */

return [

    'connection_error' => 'The website is currently under maintenance. It will be available soon. Thank you for coming back later.',

];
